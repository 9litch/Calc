//
//  ViewController.h
//  Calc
//
//  Created by Navneet Singh on 16/02/17.
//  Copyright © 2017 NASK. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property double firstVar;
@property double secondVar;

@end

