//
//  ViewController.m
//  Calc
//
//  Created by Navneet Singh on 16/02/17.
//  Copyright © 2017 NASK. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UILabel *calcLabel;

@end

@implementation ViewController
//using C-correction or AC-AllCorrection
int resetor = 0;

//negetivity checker
BOOL negativityOn = NO;

//deliberately chosen secondVar as zero
BOOL secondVarIntentionallyZero = NO;

//double operation
BOOL doubleOperation = NO;

//operator selector
int operatorSelector = 0;

//initian of a BOOL to deciding between firstVar & secondVar
BOOL selector = NO;

- (IBAction)multiplyingOperator:(id)sender {
    resetor = 1;
    selector = YES;
    operatorSelector = 1;
    if (secondVarIntentionallyZero == NO) {
        if (_secondVar == 0) {
            _secondVar = 1;
            _firstVar = _firstVar*_secondVar;
            _calcLabel.text = [NSString stringWithFormat:@"%g",_firstVar];
            _secondVar = 0;
        } else {
            _firstVar = _firstVar*_secondVar;
            doubleOperation = YES;
            _calcLabel.text = [NSString stringWithFormat:@"%g",_firstVar];
        }
    }else {
        _calcLabel.text = @"Error";
    }
}
- (IBAction)dividingOperator:(id)sender {
    resetor = 1;
    selector = YES;
    operatorSelector = 2;
    if (secondVarIntentionallyZero == NO) {
        if (_secondVar == 0) {
            _secondVar = 1;
            _firstVar = _firstVar/_secondVar;
            _calcLabel.text = [NSString stringWithFormat:@"%g",_firstVar];
            _secondVar = 0;
        } else {
            _firstVar = _firstVar/_secondVar;
            doubleOperation = YES;
            _calcLabel.text = [NSString stringWithFormat:@"%g",_firstVar];
        }
    }else {
        _calcLabel.text = @"Error";
    }

}
- (IBAction)subtractingOperator:(id)sender {
    resetor = 1;
    selector = YES;
    operatorSelector = 3;
    if (secondVarIntentionallyZero == NO) {
        _firstVar = _firstVar - _secondVar;
        doubleOperation = YES;
        _calcLabel.text = [NSString stringWithFormat:@"%g",_firstVar];
    } else {
        _calcLabel.text = @"Error";
    }
}
- (IBAction)addingOperator:(id)sender {
    resetor = 1;
    selector = YES;
    operatorSelector = 4;
    if (secondVarIntentionallyZero == NO) {
        _firstVar = _firstVar + _secondVar;
        doubleOperation = YES;
        _calcLabel.text = [NSString stringWithFormat:@"%g",_firstVar];
    } else {
        _calcLabel.text = @"Error";
    }
}

//numerical button
- (IBAction)zeroButton:(id)sender {
    if (selector == NO) {
        resetor = 1;
        if (doubleOperation == YES) {
            _firstVar = 0;
            doubleOperation = NO;
        }
        _firstVar = (_firstVar)*10 + 0;
        _calcLabel.text = [NSString stringWithFormat:@"%g",_firstVar];
    } else {
        resetor = 2;
        if (doubleOperation == YES) {
            _secondVar = 0;
            doubleOperation = NO;
        }
        _secondVar = (_secondVar)*10 + 0;
        if (_secondVar == 0) {
            secondVarIntentionallyZero = YES;
        }
        _calcLabel.text = [NSString stringWithFormat:@"%g",_secondVar];
    }

}
- (IBAction)oneButton:(id)sender {
    if (selector == NO) {
        resetor = 1;
        if (doubleOperation == YES) {
            _firstVar = 0;
            doubleOperation = NO;
        }
        if (negativityOn == NO) {
            _firstVar = (_firstVar)*10 + 1;
        } else {
            _firstVar = (_firstVar)*10 - 1;
        }
        _calcLabel.text = [NSString stringWithFormat:@"%g",_firstVar];
    } else {
        resetor = 2;
        if (doubleOperation == YES) {
            _secondVar = 0;
            doubleOperation = NO;
        }
        if (negativityOn == NO) {
            _secondVar = (_secondVar)*10 + 1;
        } else {
            _secondVar = (_secondVar)*10 - 1;
        }
        _calcLabel.text = [NSString stringWithFormat:@"%g",_secondVar];
    }
}
- (IBAction)twoButton:(id)sender {
    if (selector == NO) {
        resetor = 1;
        if (doubleOperation == YES) {
            _firstVar = 0;
            doubleOperation = NO;
        }
        if (negativityOn == NO) {
            _firstVar = (_firstVar)*10 + 2;
        } else {
            _firstVar = (_firstVar)*10 - 2;
        }
        _calcLabel.text = [NSString stringWithFormat:@"%g",_firstVar];
    } else {
        resetor = 2;
        if (doubleOperation == YES) {
            _secondVar = 0;
            doubleOperation = NO;
        }
        if (negativityOn == NO) {
            _secondVar = (_secondVar)*10 + 2;
        } else {
            _secondVar = (_secondVar)*10 - 2;
        }
        _calcLabel.text = [NSString stringWithFormat:@"%g",_secondVar];
    }
}
- (IBAction)threeButton:(id)sender {
    if (selector == NO) {
        resetor = 1;
        if (doubleOperation == YES) {
            _firstVar = 0;
            doubleOperation = NO;
        }
        if (negativityOn == NO) {
            _firstVar = (_firstVar)*10 + 3;
        } else {
            _firstVar = (_firstVar)*10 - 3;
        }
        _calcLabel.text = [NSString stringWithFormat:@"%g",_firstVar];
    } else {
        resetor = 2;
        if (doubleOperation == YES) {
            _secondVar = 0;
            doubleOperation = NO;
        }
        if (negativityOn == NO) {
            _secondVar = (_secondVar)*10 + 3;
        } else {
            _secondVar = (_secondVar)*10 - 3;
        }
        _calcLabel.text = [NSString stringWithFormat:@"%g",_secondVar];
    }
}
- (IBAction)fourButton:(id)sender {
    if (selector == NO) {
        resetor = 1;
        if (doubleOperation == YES) {
            _firstVar = 0;
            doubleOperation = NO;
        }
        if (negativityOn == NO) {
            _firstVar = (_firstVar)*10 + 4;
        } else {
            _firstVar = (_firstVar)*10 - 4;
        }
        _calcLabel.text = [NSString stringWithFormat:@"%g",_firstVar];
    } else {
        resetor = 2;
        if (doubleOperation == YES) {
            _secondVar = 0;
            doubleOperation = NO;
        }
        if (negativityOn == NO) {
            _secondVar = (_secondVar)*10 + 4;
        } else {
            _secondVar = (_secondVar)*10 - 4;
        }
        _calcLabel.text = [NSString stringWithFormat:@"%g",_secondVar];
    }
}
- (IBAction)fiveButton:(id)sender {
    if (selector == NO) {
        resetor = 1;
        if (doubleOperation == YES) {
            _firstVar = 0;
            doubleOperation = NO;
        }
        if (negativityOn == NO) {
            _firstVar = (_firstVar)*10 + 5;
        } else {
            _firstVar = (_firstVar)*10 - 5;
        }
        _calcLabel.text = [NSString stringWithFormat:@"%g",_firstVar];
    } else {
        resetor = 2;
        if (doubleOperation == YES) {
            _secondVar = 0;
            doubleOperation = NO;
        }
        if (negativityOn == NO) {
            _secondVar = (_secondVar)*10 + 5;
        } else {
            _secondVar = (_secondVar)*10 - 5;
        }
        _calcLabel.text = [NSString stringWithFormat:@"%g",_secondVar];
    }
}
- (IBAction)sixButton:(id)sender {
    if (selector == NO) {
        resetor = 1;
        if (doubleOperation == YES) {
            _firstVar = 0;
            doubleOperation = NO;
        }
        if (negativityOn == NO) {
            _firstVar = (_firstVar)*10 + 6;
        } else {
            _firstVar = (_firstVar)*10 - 6;
        }
        _calcLabel.text = [NSString stringWithFormat:@"%g",_firstVar];
    } else {
        resetor = 2;
        if (doubleOperation == YES) {
            _secondVar = 0;
            doubleOperation = NO;
        }
        if (negativityOn == NO) {
            _secondVar = (_secondVar)*10 + 6;
        } else {
            _secondVar = (_secondVar)*10 - 6;
        }
        _calcLabel.text = [NSString stringWithFormat:@"%g",_secondVar];
    }
}
- (IBAction)sevenButton:(id)sender {
    if (selector == NO) {
        resetor = 1;
        if (doubleOperation == YES) {
            _firstVar = 0;
            doubleOperation = NO;
        }
        if (negativityOn == NO) {
            _firstVar = (_firstVar)*10 + 7;
        } else {
            _firstVar = (_firstVar)*10 - 7;
        }
        _calcLabel.text = [NSString stringWithFormat:@"%g",_firstVar];
    } else {
        resetor = 2;
        if (doubleOperation == YES) {
            _secondVar = 0;
            doubleOperation = NO;
        }
        if (negativityOn == NO) {
            _secondVar = (_secondVar)*10 + 7;
        } else {
            _secondVar = (_secondVar)*10 - 7;
        }
        _calcLabel.text = [NSString stringWithFormat:@"%g",_secondVar];
    }
}
- (IBAction)eightButton:(id)sender {
    if (selector == NO) {
        resetor = 1;
        if (doubleOperation == YES) {
            _firstVar = 0;
            doubleOperation = NO;
        }
        if (negativityOn == NO) {
            _firstVar = (_firstVar)*10 + 8;
        } else {
            _firstVar = (_firstVar)*10 - 8;
        }
        _calcLabel.text = [NSString stringWithFormat:@"%g",_firstVar];
    } else {
        resetor = 2;
        if (doubleOperation == YES) {
            _secondVar = 0;
            doubleOperation = NO;
        }
        if (negativityOn == NO) {
            _secondVar = (_secondVar)*10 + 8;
        } else {
            _secondVar = (_secondVar)*10 - 8;
        }
        _calcLabel.text = [NSString stringWithFormat:@"%g",_secondVar];
    }
}
- (IBAction)nineButton:(id)sender {
    if (selector == NO) {
        resetor = 1;
        if (doubleOperation == YES) {
            _firstVar = 0;
            doubleOperation = NO;
        }
        if (negativityOn == NO) {
            _firstVar = (_firstVar)*10 + 9;
        } else {
            _firstVar = (_firstVar)*10 - 9;
        }
        _calcLabel.text = [NSString stringWithFormat:@"%g",_firstVar];
    } else {
        resetor = 2;
        if (doubleOperation == YES) {
            _secondVar = 0;
            doubleOperation = NO;
        }
        if (negativityOn == NO) {
            _secondVar = (_secondVar)*10 + 9;
        } else {
            _secondVar = (_secondVar)*10 - 9;
        }
        _calcLabel.text = [NSString stringWithFormat:@"%g",_secondVar];
    }
}

//percentage button implementation
- (IBAction)percentButton:(id)sender {
    if (selector == NO) {
        resetor = 1;
        _firstVar = _firstVar/100;
        _calcLabel.text = [NSString stringWithFormat:@"%g",_firstVar];
    } else {
        resetor = 2;
        if (_secondVar == 0) {
            _secondVar = _firstVar;
            double p = _secondVar*(_firstVar/100);
            _calcLabel.text = [NSString stringWithFormat:@"%g",p];
        }else{
            double p = _secondVar*(_firstVar/100);
            _calcLabel.text = [NSString stringWithFormat:@"%g",p];
        }
    }
    selector = NO;
    doubleOperation = YES;
}

//plus minus symbol implementation
- (IBAction)plusMinusSymbol:(id)sender {
    if (negativityOn == NO) {
        negativityOn = YES;
        if (selector == NO) {
            resetor = 1;
            _firstVar = -(_firstVar);
            _calcLabel.text = [NSString stringWithFormat:@"%g",_firstVar];
            operatorSelector = 4;
        } else {
            resetor = 2;
            _secondVar = -(_secondVar);
            _calcLabel.text = [NSString stringWithFormat:@"%g",_secondVar];
            operatorSelector = 4;
        }
    } else {
        negativityOn = NO;
        if (selector == NO) {
            resetor = 1;
            _firstVar = -(_firstVar);
            _calcLabel.text = [NSString stringWithFormat:@"%g",_firstVar];
            operatorSelector = 4;
        } else {
            resetor = 2;
            _secondVar = -(_secondVar);
            _calcLabel.text = [NSString stringWithFormat:@"%g",_secondVar];
            operatorSelector = 4;
        }
    }
}


- (IBAction)isEqualTo:(id)sender {
    resetor = 1;
    if (operatorSelector == 1) {
        if (secondVarIntentionallyZero == NO) {
            _firstVar = _firstVar * _secondVar;
            _calcLabel.text = [NSString stringWithFormat:@"%g",_firstVar];
            selector = NO;
            doubleOperation = YES;
        } else {
            _calcLabel.text = @"Error";
        }

    } else if (operatorSelector == 2){
        if (_secondVar != 0) {
            _firstVar = _firstVar / _secondVar;
            _calcLabel.text = [NSString stringWithFormat:@"%g",_firstVar];
        } else {
            _calcLabel.text = @"Error";
            secondVarIntentionallyZero = YES;
        }
        selector = NO;
        doubleOperation = YES;
    } else if (operatorSelector == 3){
        if (secondVarIntentionallyZero == NO) {
            _firstVar = _firstVar - _secondVar;
            _calcLabel.text = [NSString stringWithFormat:@"%g",_firstVar];
            selector = NO;
            doubleOperation = YES;
        } else {
            _calcLabel.text = @"Error";
        }
    } else if (operatorSelector == 4){
        if (secondVarIntentionallyZero == NO) {
            _firstVar = _firstVar + _secondVar;
            _calcLabel.text = [NSString stringWithFormat:@"%g",_firstVar];
            selector = NO;
            doubleOperation = YES;
        } else {
            _calcLabel.text = @"Error";
        }
    } else {
        _calcLabel.text = [NSString stringWithFormat:@"%g",_firstVar];
    }
    _firstVar = 0;
}

- (IBAction)resetButton:(id)sender {
    if (resetor == 0) {
        //reseting everything on calculator
        //variables
        _firstVar = 0;
        _secondVar = 0;

        //negetivity checker
        negativityOn = NO;

        //deliberately chosen secondVar as zero
        secondVarIntentionallyZero = NO;

        //double operation
        doubleOperation = NO;

        //operator selector
        operatorSelector = 0;

        //initian of a BOOL to deciding between firstVar & secondVar
        selector = NO;

        //error handling
        secondVarIntentionallyZero = NO;

        //reseting label
        _calcLabel.text = @"0";
    } else if (resetor == 1) {
        resetor = 0;

        //reseting first variable
        _firstVar = 0;

        //reseting selector
        selector = 0;

        //reseting negativity
        negativityOn = NO;

        //error handling
        secondVarIntentionallyZero = NO;

        //reseting label
        _calcLabel.text = @"0";

    } else {
        resetor = 0;

        //reseting first variable
        _secondVar = 0;

        //reseting selector
        selector = 1;

        //reseting negativity
        negativityOn = NO;

        //double operation
        doubleOperation = NO;

        //error handling
        secondVarIntentionallyZero = NO;

        //reseting label
        _calcLabel.text = @"0";
    }

}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
